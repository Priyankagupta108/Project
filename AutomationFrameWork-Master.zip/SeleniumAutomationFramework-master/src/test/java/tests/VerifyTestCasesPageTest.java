package tests;

import base.BaseTest;
import org.testng.Assert;
import org.testng.annotations.Test;
import pages.*;

public class VerifyTestCasesPageTest extends BaseTest {
    @Test
    public void testVerifyTestCasesPage() {
        HomePage home = new HomePage(driver);
        home.clickTestCases();

        TestCasesPage tc = new TestCasesPage(driver);
        Assert.assertTrue(tc.isTestCasesVisible());
    }
}
