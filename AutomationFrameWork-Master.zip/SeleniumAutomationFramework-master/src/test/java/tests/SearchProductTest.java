package tests;

import base.BaseTest;
import org.testng.Assert;
import org.testng.annotations.Test;
import pages.*;

public class SearchProductTest extends BaseTest {
    @Test
    public void testSearchProduct() {
        HomePage home = new HomePage(driver);
        home.clickProducts();

        ProductsPage products = new ProductsPage(driver);
        Assert.assertTrue(products.isAllProductsVisible());

        products.searchProduct("Tshirt");
        Assert.assertTrue(products.isSearchedProductsVisible());
    }
}
