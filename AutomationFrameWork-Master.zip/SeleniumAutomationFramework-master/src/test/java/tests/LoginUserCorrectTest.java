package tests;

import base.BaseTest;
import org.testng.Assert;
import org.testng.annotations.Test;
import pages.*;

public class LoginUserCorrectTest extends BaseTest {
    @Test
    public void testLoginCorrect() {
        HomePage home = new HomePage(driver);
        Assert.assertTrue(home.isHomePageVisible());

        home.clickSignupLogin();

        LoginPage login = new LoginPage(driver);
        Assert.assertTrue(login.isLoginVisible());

        login.login("PRIYANKA@GMAIL.COM", "pass123"); 
 
        Assert.assertTrue(home.isLoggedIn());

        home.clickDeleteAccount();
        AccountPage account = new AccountPage(driver);
        Assert.assertTrue(account.isAccountDeletedVisible());
    }
}
