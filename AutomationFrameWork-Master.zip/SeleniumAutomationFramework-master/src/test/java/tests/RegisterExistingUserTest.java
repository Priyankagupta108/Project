package tests;

import base.BaseTest;
import org.testng.Assert;
import org.testng.annotations.Test;
import pages.*;

public class RegisterExistingUserTest extends BaseTest {
    @Test
    public void testRegisterExistingUser() {
        HomePage home = new HomePage(driver);
        home.clickSignupLogin();

        LoginPage login = new LoginPage(driver);
        Assert.assertTrue(login.isNewUserSignupVisible());

        login.signup("Priyanka", "PRIYANKA@GMAIL.COM"); 

        Assert.assertTrue(login.isExistingEmailErrorVisible());
    }
}
