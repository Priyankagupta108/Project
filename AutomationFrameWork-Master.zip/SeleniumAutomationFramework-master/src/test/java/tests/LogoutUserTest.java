package tests;

import base.BaseTest;
import org.testng.Assert;
import org.testng.annotations.Test;
import pages.*;

public class LogoutUserTest extends BaseTest {
    @Test
    public void testLogout() {
        HomePage home = new HomePage(driver);
        home.clickSignupLogin();

        LoginPage login = new LoginPage(driver);
        login.login("Gupta@gmail.com", "12345"); 

        Assert.assertTrue(home.isLoggedIn());

        driver.findElement(org.openqa.selenium.By.xpath("//a[@href='/logout']")).click();

        Assert.assertTrue(login.isLoginVisible());
    }
}
