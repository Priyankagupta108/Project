package tests;

import base.BaseTest;
import org.testng.Assert;
import org.testng.annotations.Test;
import pages.*;

public class VerifyProductsTest extends BaseTest {
    @Test
    public void testVerifyProducts() {
        HomePage home = new HomePage(driver);
        home.clickProducts();

        ProductsPage products = new ProductsPage(driver);
        Assert.assertTrue(products.isAllProductsVisible());
        Assert.assertTrue(products.isProductListVisible());

        products.clickFirstViewProduct();

        Assert.assertTrue(products.isProductDetailsVisible());
    }
}
