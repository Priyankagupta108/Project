package tests;

import base.BaseTest;
import org.testng.Assert;
import org.testng.annotations.Test;
import pages.*;

public class RegisterUserTest extends BaseTest {

    @Test
    public void testRegisterUser() {
        HomePage home = new HomePage(driver);
        Assert.assertTrue(home.isHomePageVisible());

        home.clickSignupLogin();

        LoginPage login = new LoginPage(driver);
        Assert.assertTrue(login.isNewUserSignupVisible());

        String email = "shraddha" + System.currentTimeMillis() + "@mail.com";
        login.signup("shraddha", email);

        SignupPage signup = new SignupPage(driver);
        Assert.assertTrue(signup.isEnterAccountInfoVisible());

        signup.fillAccountForm("Priyanka", "pass123", "09", "Feb", "2004",
                "Priyanka", "Gupta", "TSS Consultancy", "Rajkot", "India",
                "Gujarat", "Rajkot", "360001", "9999999999");
        signup.clickCreateAccount();

        AccountPage account = new AccountPage(driver);
        Assert.assertTrue(account.isAccountCreatedVisible());
        account.clickContinue();

        Assert.assertTrue(home.isLoggedIn());

        home.clickDeleteAccount();
        Assert.assertTrue(account.isAccountDeletedVisible());
        account.clickContinue();
    }
}
