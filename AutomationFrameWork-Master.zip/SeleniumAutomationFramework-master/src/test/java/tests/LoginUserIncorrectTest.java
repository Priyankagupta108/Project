package tests;

import base.BaseTest;
import org.testng.Assert;
import org.testng.annotations.Test;
import pages.*;

public class LoginUserIncorrectTest extends BaseTest {
    @Test
    public void testLoginIncorrect() {
        HomePage home = new HomePage(driver);
        home.clickSignupLogin();

        LoginPage login = new LoginPage(driver);
        Assert.assertTrue(login.isLoginVisible());

        login.login("xyz1@mail.com", "P2534G");

        Assert.assertTrue(login.isLoginErrorVisible());
    }
}
