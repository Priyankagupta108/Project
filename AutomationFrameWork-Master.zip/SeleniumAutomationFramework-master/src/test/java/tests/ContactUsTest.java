package tests;

import base.BaseTest;
import org.testng.Assert;
import org.testng.annotations.Test;
import pages.*;

public class ContactUsTest extends BaseTest {
    @Test
    public void testContactUs() {
        HomePage home = new HomePage(driver);
        home.clickContactUs();

        ContactUsPage contact = new ContactUsPage(driver);
        Assert.assertTrue(contact.isGetInTouchVisible());

        contact.fillForm("Priyanka", "priyanka@mail.com", "Help", "This is test message");
        contact.uploadFile("C:\\Users\\ABC\\Downloads\\IMG20230605141343copy538x3641.jpg"); // file path
        contact.clickSubmit();

        Assert.assertTrue(contact.isSuccessMessageVisible());

        contact.clickHome();
        Assert.assertTrue(home.isHomePageVisible());
    }
}
