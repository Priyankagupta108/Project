package tests;

import base.BaseTest;
import org.testng.Assert;
import org.testng.annotations.Test;
import pages.HomePage;

import org.openqa.selenium.By;

public class VerifySubscriptionTest extends BaseTest {
    @Test
    public void testVerifySubscription() {
        HomePage home = new HomePage(driver);
        Assert.assertTrue(home.isHomePageVisible());

        driver.findElement(By.id("susbscribe_email")).sendKeys("test" + System.currentTimeMillis() + "@mail.com");
        driver.findElement(By.id("subscribe")).click();

        Assert.assertTrue(driver.findElement(By.xpath("//div[contains(text(),'You have been successfully subscribed!')]")).isDisplayed());
    }
}
