package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class ContactPage extends BasePage {
	private final By getInTouch = By.xpath("//h2[contains(text(),'Get In Touch') or contains(text(),'GET IN TOUCH')]");
	private final By name = By.name("name");
	private final By email = By.name("email");
	private final By subject = By.name("subject");
	private final By message = By.id("message");
	private final By upload = By.name("upload_file");
	private final By submit = By.name("submit");
	private final By successText = By.xpath("//div[contains(text(),'Success!') and not(contains(@style,'display: none'))]");
	private final By homeBtn = By.xpath("//a[contains(text(),'Home')]");

	public ContactPage(WebDriver driver) {
		super(driver);
	}

	public boolean isGetInTouchVisible() {
		try {
			return waitVisible(getInTouch).isDisplayed();
		} catch (Exception e) {
			return false;
		}
	}

	public void fillContactForm(String nm, String em, String subj, String msg, String uploadPath) {
		type(name, nm);
		type(email, em);
		type(subject, subj);
		type(message, msg);
		if (uploadPath != null) {
			waitVisible(upload).sendKeys(uploadPath);
		}
	}

	public void submitForm() {
		click(submit);
		try {
			driver.switchTo().alert().accept();
		} catch (Exception e) {
		}
	}

	public boolean isSuccessVisible() {
		try {
			return waitVisible(successText).isDisplayed();
		} catch (Exception e) {
			return false;
		}
	}

	public HomePage goHome() {
		click(homeBtn);
		return new HomePage(driver);
	}
}