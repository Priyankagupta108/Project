  package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class AccountPage {
    WebDriver driver;

    private By accountCreatedMsg = By.xpath("//h2[b[text()='Account Created!']]");
    private By accountDeletedMsg = By.xpath("//h2[b[text()='Account Deleted!']]");
    private By continueBtn = By.xpath("//a[@data-qa='continue-button']");

    public AccountPage(WebDriver driver) {
        this.driver = driver;
    }

    public boolean isAccountCreatedVisible() {
        return driver.findElement(accountCreatedMsg).isDisplayed();
    }

    public boolean isAccountDeletedVisible() {
        return driver.findElement(accountDeletedMsg).isDisplayed();
    }

    public void clickContinue() {
        driver.findElement(continueBtn).click();
    }
}
