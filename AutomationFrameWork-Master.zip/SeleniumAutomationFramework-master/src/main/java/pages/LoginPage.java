package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class LoginPage {
    WebDriver driver;

    private By newUserSignupText = By.xpath("//h2[text()='New User Signup!']");
    private By signupName = By.name("name");
    private By signupEmail = By.xpath("//input[@data-qa='signup-email']");
    private By signupBtn = By.xpath("//button[text()='Signup']");

    private By loginHeader = By.xpath("//h2[text()='Login to your account']");
    private By loginEmail = By.xpath("//input[@data-qa='login-email']");
    private By loginPassword = By.xpath("//input[@data-qa='login-password']");
    private By loginBtn = By.xpath("//button[text()='Login']");
    private By loginError = By.xpath("//p[text()='Your email or password is incorrect!']");
    private By existingEmailError = By.xpath("//p[text()='Email Address already exist!']");

    public LoginPage(WebDriver driver) {
        this.driver = driver;
    }

    public boolean isNewUserSignupVisible() {
        return driver.findElement(newUserSignupText).isDisplayed();
    }

    public void signup(String name, String email) {
        driver.findElement(signupName).sendKeys(name);
        driver.findElement(signupEmail).sendKeys(email);
        driver.findElement(signupBtn).click();
    }

    public boolean isLoginVisible() {
        return driver.findElement(loginHeader).isDisplayed();
    }

    public void login(String email, String password) {
        driver.findElement(loginEmail).sendKeys(email);
        driver.findElement(loginPassword).sendKeys(password);
        driver.findElement(loginBtn).click();
    }

    public boolean isLoginErrorVisible() {
        return driver.findElement(loginError).isDisplayed();
    }

    public boolean isExistingEmailErrorVisible() {
        return driver.findElement(existingEmailError).isDisplayed();
    }
}
