package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class ProductsPage {
    WebDriver driver;

    private By allProductsHeader = By.xpath("//h2[text()='All Products']");
    private By productList = By.cssSelector(".features_items");
    private By firstViewProductBtn = By.xpath("(//a[text()='View Product'])[1]");
    private By productName = By.xpath("//div[@class='product-information']/h2");
    private By category = By.xpath("//p[contains(text(),'Category')]");
    private By price = By.xpath("//div[@class='product-information']//span/span");
    private By availability = By.xpath("//b[text()='Availability:']");
    private By condition = By.xpath("//b[text()='Condition:']");
    private By brand = By.xpath("//b[text()='Brand:']");
    private By searchBox = By.id("search_product");
    private By searchBtn = By.id("submit_search");
    private By searchedProductsHeader = By.xpath("//h2[text()='Searched Products']");

    public ProductsPage(WebDriver driver) {
        this.driver = driver;
    }

    public boolean isAllProductsVisible() {
        return driver.findElement(allProductsHeader).isDisplayed();
    }

    public boolean isProductListVisible() {
        return driver.findElement(productList).isDisplayed();
    }

    public void clickFirstViewProduct() {
        driver.findElement(firstViewProductBtn).click();
    }

    public boolean isProductDetailsVisible() {
        return driver.findElement(productName).isDisplayed()
                && driver.findElement(category).isDisplayed()
                && driver.findElement(price).isDisplayed()
                && driver.findElement(availability).isDisplayed()
                && driver.findElement(condition).isDisplayed()
                && driver.findElement(brand).isDisplayed();
    }

    public void searchProduct(String product) {
        driver.findElement(searchBox).sendKeys(product);
        driver.findElement(searchBtn).click();
    }

    public boolean isSearchedProductsVisible() {
        return driver.findElement(searchedProductsHeader).isDisplayed();
    }
}
