package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class ContactUsPage {
    WebDriver driver;

    private By getInTouchText = By.xpath("//h2[text()='Get In Touch']");
    private By nameField = By.name("name");
    private By emailField = By.name("email");
    private By subjectField = By.name("subject");
    private By messageField = By.id("message");
    private By uploadFile = By.name("upload_file");
    private By submitBtn = By.name("submit");
    private By successMsg = By.xpath("//div[@class='status alert alert-success']");
    private By homeBtn = By.xpath("//a[@class='btn btn-success']");

    public ContactUsPage(WebDriver driver) {
        this.driver = driver;
    }

    public boolean isGetInTouchVisible() {
        return driver.findElement(getInTouchText).isDisplayed();
    }

    public void fillForm(String name, String email, String subject, String message) {
        driver.findElement(nameField).sendKeys(name);
        driver.findElement(emailField).sendKeys(email);
        driver.findElement(subjectField).sendKeys(subject);
        driver.findElement(messageField).sendKeys(message);
    }

    public void uploadFile(String filePath) {
        driver.findElement(uploadFile).sendKeys(filePath);
    }

    public void clickSubmit() {
        driver.findElement(submitBtn).click();
        driver.switchTo().alert().accept(); // handle alert
    }

    public boolean isSuccessMessageVisible() {
        return driver.findElement(successMsg).isDisplayed();
    }

    public void clickHome() {
        driver.findElement(homeBtn).click();
    }
}
