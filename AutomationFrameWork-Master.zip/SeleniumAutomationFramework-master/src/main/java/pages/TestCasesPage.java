package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class TestCasesPage {
    WebDriver driver;

    private By testCasesHeader = By.xpath("//b[text()='Test Cases']");

    public TestCasesPage(WebDriver driver) {
        this.driver = driver;
    }

    public boolean isTestCasesVisible() {
        return driver.findElement(testCasesHeader).isDisplayed();
    }
}
