package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class HomePage {
    WebDriver driver;

    private By signupLoginBtn = By.xpath("//a[@href='/login']");
    private By contactUsBtn = By.xpath("//a[@href='/contact_us']");
    private By productsBtn = By.xpath("//a[@href='/products']");
    private By testCasesBtn = By.xpath("//a[@href='/test_cases']");
    private By subscriptionText = By.xpath("//h2[text()='Subscription']");
    private By deleteAccountBtn = By.xpath("//a[@href='/delete_account']");
    private By loggedInText = By.xpath("//a[contains(text(),'Logged in as')]");

    public HomePage(WebDriver driver) {
        this.driver = driver;
    }

    public boolean isHomePageVisible() {
        return driver.getTitle().contains("Automation Exercise");
    }

    public void clickSignupLogin() {
        driver.findElement(signupLoginBtn).click();
    }

    public void clickContactUs() {
        driver.findElement(contactUsBtn).click();
    }

    public void clickProducts() {
        driver.findElement(productsBtn).click();
    }

    public void clickTestCases() {
        driver.findElement(testCasesBtn).click();
    }

    public boolean isSubscriptionVisible() {
        return driver.findElement(subscriptionText).isDisplayed();
    }

    public void clickDeleteAccount() {
        driver.findElement(deleteAccountBtn).click();
    }

    public boolean isLoggedIn() {
        return driver.findElement(loggedInText).isDisplayed();
    }
}
