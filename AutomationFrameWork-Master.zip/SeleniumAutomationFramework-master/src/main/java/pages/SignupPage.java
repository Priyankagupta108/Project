package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class SignupPage {
    WebDriver driver;

    private By enterAccountInfo = By.xpath("//b[text()='Enter Account Information']");
    private By passwordField = By.id("password");
    private By dayDropdown = By.id("days");
    private By monthDropdown = By.id("months");
    private By yearDropdown = By.id("years");

    private By newsletterChk = By.id("newsletter");
    private By offersChk = By.id("optin");

    private By firstNameField = By.id("first_name");
    private By lastNameField = By.id("last_name");
    private By companyField = By.id("company");
    private By address1Field = By.id("address1");
    private By countryDropdown = By.id("country");
    private By stateField = By.id("state");
    private By cityField = By.id("city");
    private By zipcodeField = By.id("zipcode");
    private By mobileField = By.id("mobile_number");

    private By createAccountBtn = By.xpath("//button[text()='Create Account']");

    public SignupPage(WebDriver driver) {
        this.driver = driver;
    }

    public boolean isEnterAccountInfoVisible() {
        return driver.findElement(enterAccountInfo).isDisplayed();
    }

    public void fillAccountForm(String name, String password, String day, String month, String year,
                                String fName, String lName, String company, String address, String country,
                                String state, String city, String zip, String mobile) {
        driver.findElement(passwordField).sendKeys(password);
        driver.findElement(dayDropdown).sendKeys(day);
        driver.findElement(monthDropdown).sendKeys(month);
        driver.findElement(yearDropdown).sendKeys(year);

        driver.findElement(newsletterChk).click();
        driver.findElement(offersChk).click();

        driver.findElement(firstNameField).sendKeys(fName);
        driver.findElement(lastNameField).sendKeys(lName);
        driver.findElement(companyField).sendKeys(company);
        driver.findElement(address1Field).sendKeys(address);
        driver.findElement(countryDropdown).sendKeys(country);
        driver.findElement(stateField).sendKeys(state);
        driver.findElement(cityField).sendKeys(city);
        driver.findElement(zipcodeField).sendKeys(zip);
        driver.findElement(mobileField).sendKeys(mobile);
    }

    public void clickCreateAccount() {
        driver.findElement(createAccountBtn).click();
    }
}
