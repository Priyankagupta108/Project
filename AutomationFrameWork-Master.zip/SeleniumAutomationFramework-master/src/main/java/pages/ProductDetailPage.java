package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class ProductDetailPage extends BasePage {
	private final By productName = By.xpath("//h2");
	private final By category = By.xpath("//p2[contains(text(),'Category')]");
	private final By price = By
			.xpath("//span[contains(text(),'Rs.') or contains(text(),'$') or contains(text(),'Price')]");
	private final By availability = By.xpath("//b[contains(text(),'Availability') or contains(text(),'availability')]");
	private final By condition = By.xpath("//b[contains(text(),'Condition') or contains(text(),'condition')]");
	private final By brand = By.xpath("//b[contains(text(),'Brand') or contains(text(),'brand')]");

	public ProductDetailPage(WebDriver driver) {
		super(driver);
	}

	public boolean verifyProductDetails() {
		try {
			waitVisible(productName);
			waitVisible(category);
			waitVisible(price);
			waitVisible(availability);
			waitVisible(condition);
			waitVisible(brand);
			return true;
		} catch (Exception e) {
			return false;
		}
	}
}