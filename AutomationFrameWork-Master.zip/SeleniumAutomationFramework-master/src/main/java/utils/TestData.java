package utils;

public class TestData {
	public static final String PASSWORD = "Test1234!";

	public static String uniqueEmail(String prefix) {
		String stamp = String.valueOf(System.currentTimeMillis());
		return prefix + stamp + "@example.com";
	}
}
