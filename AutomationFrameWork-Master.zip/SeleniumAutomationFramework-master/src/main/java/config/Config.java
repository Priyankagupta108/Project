package config;

public class Config {
public static final String BASE_URL = "http://automationexercise.com";
public static final int TIMEOUT = 15; // seconds
}
